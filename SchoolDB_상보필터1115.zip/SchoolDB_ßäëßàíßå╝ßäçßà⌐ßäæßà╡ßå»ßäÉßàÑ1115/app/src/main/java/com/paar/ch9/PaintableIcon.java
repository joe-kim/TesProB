package com.paar.ch9;

import android.graphics.Bitmap;
import android.graphics.Canvas;

public class PaintableIcon extends PaintableObject { //트위터와 위키피디아에 사용되는 아이템을 그리는 클래스
    private Bitmap bitmap=null;

    private double dist=0;

    public PaintableIcon(Bitmap bitmap, int width, int height, double dist) {
        set(bitmap,width,height);
        this.dist = dist;   //dist 추가
    }
    public void set(Bitmap bitmap, int width, int height) {
    	if (bitmap==null) throw new NullPointerException();
    	
        this.bitmap = Bitmap.createScaledBitmap(bitmap, width, height, true);
    }

	@Override
    public void paint(Canvas canvas) {
    	if (canvas==null || bitmap==null) throw new NullPointerException();

        paintBitmap(canvas, bitmap, -(bitmap.getWidth()/2), -(bitmap.getHeight()/2), dist); //dist 추가
    }

	@Override
    public float getWidth() {
        return bitmap.getWidth();
    } //최종적으로 그려지는 비트맵의 너비 반환

	@Override
    public float getHeight() {
        return bitmap.getHeight();
    }//최종적으로 그려지는 비트맵의 높이 반환
}