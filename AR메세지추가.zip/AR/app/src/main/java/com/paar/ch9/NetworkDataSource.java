package com.paar.ch9;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

public abstract class NetworkDataSource extends DataSource { // 얻어온 url을 json으로 바꿔주는 클래스
    //protected static final int MAX = 1000; // 한번에 받을 마커의 최소 갯수를 지정해줌
    protected static final int MAX = 200;

    protected static final int READ_TIMEOUT = 10000;    //읽기 타임아웃까지 10000밀리초
    protected static final int CONNECT_TIMEOUT = 10000; //연결 타임아웃까지 10000밀리초

    protected List<Marker> markersCache = null; //임시 마커를 저장하기 위한 배열 선언
    
    public abstract String createRequestURL(double lat, double lon, double alt,
                                            float radius, String locale);

    public abstract List<Marker> parse(JSONObject root);

    public List<Marker> getMarkers() {
        return markersCache;
    }

    public List<Marker> parse(String url) { // 여기 소스코드 변경
        if (url == null)
            throw new NullPointerException();

        InputStream stream = null;
        stream = getHttpGETInputStream(url);
        if (stream == null)
            throw new NullPointerException();

        String string = null;
        string = getHttpInputString(stream);
        if (string == null)
            throw new NullPointerException();

        JSONObject json = null; //데이터 소스로부터 JSOn오브젝트를 얻어서 다른 parse()메소드를 호출한다
        try {
            json = new JSONObject(string);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (json == null)
            throw new NullPointerException();
        
        return parse(json); //다른 클래스에서 오버라이드되고 구현된다.
    }
    protected static InputStream getHttpGETInputStream(String urlStr) { //inputstream을 얻기 위한 메소드
        if (urlStr == null)
            throw new NullPointerException();

        InputStream is = null;
        URLConnection conn = null;

        try {
            if (urlStr.startsWith("file://"))//시작이 file:// 면
                return new FileInputStream(urlStr.replace("file://", "")); //지운다

            URL url = new URL(urlStr);//URL로 만들고
            conn = url.openConnection();//연결하고
            conn.setReadTimeout(READ_TIMEOUT);//타임아웃 지정
            conn.setConnectTimeout(CONNECT_TIMEOUT);//타임아웃 지정

            is = conn.getInputStream();//inputstream한다

            return is;//inputstream 리턴한다
        } catch (Exception ex) {
            try {
                is.close(); //예외 발생하면 닫는다
            } catch (Exception e) {
                // Ignore
            }
            try {
                if (conn instanceof HttpURLConnection) //비교해서 같으면
                    ((HttpURLConnection) conn).disconnect(); //연결해제한다
            } catch (Exception e) {
                // Ignore
            }
            ex.printStackTrace();
        }

        return null;
    }

    protected String getHttpInputString(InputStream is) { //inputstream의 값(is)를 받아서 스트링에 입력시킨다
        if (is == null)
            throw new NullPointerException();

        BufferedReader reader = new BufferedReader(new InputStreamReader(is),
                8 * 1024);  //리더에 is를 넣는다
        StringBuilder sb = new StringBuilder();

        try {
            String line;
            while ((line = reader.readLine()) != null) { //리더(is)가 널이 아니면 개행한다
                sb.append(line + "\n"); //개행하여 sb에 저장
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();//sb를 스트링으로 리턴한다
    }
}