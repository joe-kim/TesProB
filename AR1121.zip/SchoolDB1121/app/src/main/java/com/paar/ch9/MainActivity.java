package com.paar.ch9;

import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AugmentedActivity {
    private static final String TAG = "MainActivity";

    private SQLiteDatabase db;///
    private DataBaseHelper mDBHelper;/////
    private ArrayList<SchoolDB> mSchoolDBList = new ArrayList<SchoolDB>();
    private ArrayList<SchoolDB> mCashList = new ArrayList<SchoolDB>();
    private static Bitmap icon;
    private static int i = 0; //디버깅 위해
    private static int j = 0; //디버깅 위해

    private static final BlockingQueue<Runnable> queue = new ArrayBlockingQueue<Runnable>(1);//작업 단순화 위해 변수 설정
    private static final ThreadPoolExecutor exeService = new ThreadPoolExecutor(1, 1, 20, TimeUnit.SECONDS, queue);//ThreadPoolExecutor와 함께 인자의 queue를 가리킨다.
    private static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("@#");//토스트 시에 거리 값을 변환하기 위해 사용

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("test","onCreateBF");

        mDBHelper = new DataBaseHelper(this);////----------------------------
        //db 확인
        File database = getApplicationContext().getDatabasePath(DataBaseHelper.DBNAME);
        if(false==database.exists()){
            mDBHelper.getReadableDatabase();
            //카피 db
            if(copyDatabase(this)){
                Toast.makeText(this,"Copy database succes",Toast.LENGTH_SHORT).show();
            } else{
                Toast.makeText(this,"Copy data error",Toast.LENGTH_SHORT).show();
                return;
            }
        }
    icon = createIcon(this.getResources());
    db=mDBHelper.getReadableDatabase();
    Log.d("test","next");
    mSchoolDBList = selectAll();
}

    public ArrayList<SchoolDB> selectAll(){
        String sql = "SELECT * FROM School";
        SchoolDB mCashSchoolDB;

        Log.d("test","noProblum");
        try {
            Cursor results = db.rawQuery(sql, null);
            results.moveToFirst();
            Log.d("test","fine");
            while (!results.isAfterLast()) {
                int id = results.getInt(0);
                Log.d("test","getid");
                String Location = results.getString(1);
                Log.d("test","getLocation");
                double Lat = results.getDouble(2);
                Log.d("test","getLat");
                double Lon = results.getDouble(3);
                Log.d("test","getLon");
                double Alt = results.getDouble(4);
                Log.d("test","getAlt");
                Log.d("test", "index=" + id + ", Location=" + Location + ", Lat=" + Lat + ", Lon=" + Lon+", Alt="+ Alt);
                mCashSchoolDB = new SchoolDB(id, Location, Lat, Lon, Alt);
                Log.d("test","okay");
                if(mCashSchoolDB != null) {
                        mCashList.add(mCashSchoolDB);
                        Log.d("test", "finish " + i);
                }
                results.moveToNext();
                i++;
            }
            results.close();
        }catch (NullPointerException e){
            e.printStackTrace();
        }
        return mCashList;
    }

    private boolean copyDatabase(Context context)
    {
        try{
            InputStream inputStream = context.getAssets().open(DataBaseHelper.DBNAME);
            String outFileName = DataBaseHelper.DBLOCATION+ DataBaseHelper.DBNAME;
            OutputStream outputStream=new FileOutputStream(outFileName);
            byte[]buff = new byte[1024];
            int length=0;
            while((length = inputStream.read(buff))>0){
                outputStream.write(buff,0,length);
            }
            outputStream.flush();
            outputStream.close();
            Log.v("MainActivity","DB copied");
            return true;
        }catch(Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    protected Bitmap createIcon(Resources res) {
        if (res==null) throw new NullPointerException();
        return BitmapFactory.decodeResource(res, R.drawable.cctv); //CCTV 이미지로 바꿈
    }
    @Override
    public void onStart() {
        super.onStart();
        Location last = ARData.getCurrentLocation();//가장 최근의 위치를 ARData에서 얻어와서 저장하고
        updateData();//최신위치의 경도위도고도 값을 업데이트한다
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) { //메뉴바 설정한다
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.v(TAG, "onOptionsItemSelected() item="+item);
        switch (item.getItemId()) {
            case R.id.showRadar:
                showRadar = !showRadar;//현재값이 트루라면 폴스가 나타남
                item.setTitle(((showRadar)? "Hide" : "Show")+" Radar");
                break;
            case R.id.showZoomBar:
                showZoomBar = !showZoomBar; //마찬가지
                item.setTitle(((showZoomBar)? "Hide" : "Show")+" Zoom Bar");
                zoomLayout.setVisibility((showZoomBar)? LinearLayout.VISIBLE:LinearLayout.GONE);
                break;
            case R.id.exit:
                finish();
                break;
        }
        return true;
    }
	@Override
    public void onLocationChanged(Location location) {
        super.onLocationChanged(location);
        //거리 측정해서 아이콘 투명도 조절하는 함수 - marker.getDistance()
        updateData();  //지역이 변경되면 업데이트한다
    }
	@Override
	protected void markerTouched(Marker marker) {

        if (marker.getDistance()<1000.0) {
            String dis = DECIMAL_FORMAT.format(marker.getDistance()) + "m";
            Toast t = Toast.makeText(getApplicationContext(),
                    marker.getName()+"까지 "+ dis +" 남았습니다",
                    Toast.LENGTH_SHORT);//t에 마커 이름 넘겨준다
            t.setGravity(Gravity.CENTER, 0, 0);//마커를 가운데에 뛰우고 마커이름을 짧게 토스트한다
            t.show();
        } else {
            String dis = DECIMAL_FORMAT.format(marker.getDistance()/1000) + "km";
            Toast t = Toast.makeText(getApplicationContext(),
                    marker.getName()+"까지 "+ dis +" 남았습니다",
                    Toast.LENGTH_SHORT);//t에 마커 이름 넘겨준다
            t.setGravity(Gravity.CENTER, 0, 0);//마커를 가운데에 뛰우고 마커이름을 짧게 토스트한다
            t.show();
        }
	}
    private void updateData() {
        try {
            exeService.execute(
                new Runnable() {    //Runnable()을 이용하여 위키나 트위터의 source를 다운로드한다

                    public void run() {
                        try{
                        for (SchoolDB mSchoolDB : mSchoolDBList) {
                            Log.d("test","download 실행 "+ j);
                            download(mSchoolDB);
                        }
                        }catch (NullPointerException e){
                            e.printStackTrace();
                        }
                    }
                }
            );
        } catch (RejectedExecutionException rej) {//자료를 받을 큐 공간이 부족하면 예외발생 시
            Log.w(TAG, "Not running new download Runnable, queue is full.");
        } catch (Exception e) { //그외의 예외 발생 시
            Log.e(TAG, "Exception running download Runnable.",e);
        }
    }
    private static boolean download(SchoolDB mSchoolDB) {
        if (mSchoolDB == null) {
            Log.d(TAG, "Can`t connect with DB");
            return false;
        }
        Marker ma = null;
        ArrayList<Marker> markers = new ArrayList<Marker>();
        Log.d("test","Good");
        {
            try {
                ma = new IconMarker(
                        mSchoolDB.getLocation(),
                        mSchoolDB.getLat(),
                        mSchoolDB.getLon(),
                        mSchoolDB.getAlt()+15,
                        Color.YELLOW,
                        icon);
               /* ma = new IconMarker(
                        mSchoolDB.getLocation(),
                        mSchoolDB.getLat(),
                        mSchoolDB.getLon(),
                        ARData.getCurrentLocation().getAltitude()+6,
                        Color.YELLOW,
                        icon);*/
                Log.d("test","make ma : "+j);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if(ma != null){
                markers.add(ma);
                Log.d("test","add ma to markers : "+j);
            }
            ARData.addMarkers(markers);//ARData에 마커 추가한다
            Log.d("test","add markers to ARData : "+j);
            j++;
            return true;
        }
    }
}