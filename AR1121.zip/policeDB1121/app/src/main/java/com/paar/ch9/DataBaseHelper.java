package com.paar.ch9;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*
 * Created by gkdtn on 2016-10-28.
 .*/

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "gpsdb.db";
    public static final String DBLOCATION = "/data/data/com.paar.ch9/databases/";
    private Context mContext;
    private SQLiteDatabase mDatabase;

    public DataBaseHelper(Context context)
    {
        super(context,DBNAME,null,1);
        this.mContext=context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void openDatabase(){
        String dbpath=mContext.getDatabasePath(DBNAME).getPath();
        if(mDatabase!=null&& mDatabase.isOpen()){
            return;
        }
        mDatabase=SQLiteDatabase.openDatabase(dbpath,null,SQLiteDatabase.OPEN_READWRITE);
    }

    public void closeDatabase()
    {
        if(mDatabase!=null){
            mDatabase.close();
        }
    }
}
