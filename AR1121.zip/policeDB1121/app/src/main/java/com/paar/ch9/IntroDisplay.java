package com.paar.ch9;/*
package com.paar.ch9;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.ImageView;

*/
/**
 * Created by kimjiho on 2016. 11. 11..
 *//*


public class IntroDisplay extends Activity {

    private Handler mHandler;
    private Runnable mRunnable;
    private ImageView mImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.introdisplay);
        mImageView = (ImageView)findViewById(R.id.cctv);
        mRunnable = new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext()
                        , MainActivity.class);
                startActivity(intent);
            }
        };
        mHandler = new Handler();
        mHandler.postDelayed(mRunnable, 4000);
    }
    @Override
    protected void onDestroy() {
        Log.i("test", "onDstory()");
        mHandler.removeCallbacks(mRunnable);
        super.onDestroy();
    }
}
*/
