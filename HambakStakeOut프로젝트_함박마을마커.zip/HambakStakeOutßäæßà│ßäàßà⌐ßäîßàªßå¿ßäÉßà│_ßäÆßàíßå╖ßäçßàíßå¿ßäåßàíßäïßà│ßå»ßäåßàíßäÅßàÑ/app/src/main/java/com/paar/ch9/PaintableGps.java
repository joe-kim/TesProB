package com.paar.ch9;

import android.graphics.Canvas;

public class PaintableGps extends PaintableObject { //그려지는 원의 선 두께를 설정할 수 있는 클래스 - PaintableCircle과 비슷하다
    private float radius = 0;
    private float strokeWidth = 0;
    private boolean fill = false;
    private int color = 0;
    
    public PaintableGps(float radius, float strokeWidth, boolean fill, int color) {
    	set(radius, strokeWidth, fill, color);
    }

    public void set(float radius, float strokeWidth, boolean fill, int color) {
        this.radius = radius;
        this.strokeWidth = strokeWidth;
        this.fill = fill;
        this.color = color;
    }

	@Override
    public void paint(Canvas canvas) {
    	if (canvas==null) throw new NullPointerException();
    	
        setStrokeWidth(strokeWidth); // 선 두께 설정
        setFill(fill);
        setColor(color);
        paintCircle(canvas, 0, 0, radius);
    }

	@Override
    public float getWidth() {
        return radius*2;
    }

	@Override
    public float getHeight() {
	    return radius*2;
    }
}