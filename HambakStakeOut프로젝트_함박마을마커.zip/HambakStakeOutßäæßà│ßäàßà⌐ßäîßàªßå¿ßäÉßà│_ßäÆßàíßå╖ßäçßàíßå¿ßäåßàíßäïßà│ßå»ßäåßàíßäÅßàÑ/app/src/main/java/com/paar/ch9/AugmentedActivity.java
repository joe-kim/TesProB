package com.paar.ch9;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;

import java.text.DecimalFormat;

public class AugmentedActivity extends SensorsActivity implements OnTouchListener {
    //AugmentedView를 확장해서 화면에 띄울 카메라와 레이아웃 설정하고 줌바(seekBar)를 선언하고 값을 할당하는 클래스
    private static final String TAG = "AugmentedActivity";
    private static final DecimalFormat FORMAT = new DecimalFormat("#.##");  //레이더에 현재반경 표시할 때 나타내는 포멧형식 지정
    protected static WakeLock wakeLock = null;  //카메라 꺼짐켜짐 확인
    protected static CameraSurface camScreen = null;    //카메라 할당

    protected static LinearLayout zoomLayout = null;    //SeekBar 레이아웃 선언
    protected static AugmentedView augmentedView = null;    //AugmentedView를 확장

    public static boolean showRadar = true; //레이더 표시할지 안할지 판별
    public static boolean showZoomBar = true;   //시크바 표시할지 안할지 판별

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        camScreen = new CameraSurface(this);
        setContentView(camScreen);  //카메라 surface선언

        augmentedView = new AugmentedView(this);    //뷰 확장하여 할당
        augmentedView.setOnTouchListener(this); //뷰 리스너 설정
        LayoutParams augLayout = new LayoutParams(  LayoutParams.WRAP_CONTENT, 
                                                    LayoutParams.WRAP_CONTENT);
        addContentView(augmentedView,augLayout);    //augmentedView를 Wrap-ConTent로 하여 Content에 추가

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);   //화면을 켜고 사용하지 않는 상태에서는
                                        // 어둡게 보이게하는 WakeLock을 얻어오기 위해 파워 메니저 시스템 서비스를 선언
        wakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "DimScreen"); //할당해줌
    }

	@Override
	public void onResume() {
		super.onResume();

		wakeLock.acquire(); //실행중에 사용할 수 있게함
	}

	@Override
	public void onPause() {
		super.onPause();

		wakeLock.release(); //반환
	}
	
	@Override
    public void onSensorChanged(SensorEvent evt) {
        super.onSensorChanged(evt);

        if (    evt.sensor.getType() == Sensor.TYPE_ACCELEROMETER || 
                evt.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
        {
            augmentedView.postInvalidate(); //센서가 변화되면 augmentedView를 무효화시키고 다시 onDraw()한다
        }
    }

	public boolean onTouch(View view, MotionEvent me) { //마커를 터치했을 때 작동하는 터치 메소드
	    for (Marker marker : ARData.getMarkers()) {
	        if (marker.handleClick(me.getX(), me.getY())) {
	            if (me.getAction() == MotionEvent.ACTION_UP) markerTouched(marker);
	            return true;
	        }
	    }
		return super.onTouchEvent(me);
	};
	
	protected void markerTouched(Marker marker) {
		Log.w(TAG,"markerTouched() not implemented."); //아무일도 일어나지 않는다고 선언함 - 나중에 바꿔도 될 듯 - 간략하게 토스트라도
	}
}