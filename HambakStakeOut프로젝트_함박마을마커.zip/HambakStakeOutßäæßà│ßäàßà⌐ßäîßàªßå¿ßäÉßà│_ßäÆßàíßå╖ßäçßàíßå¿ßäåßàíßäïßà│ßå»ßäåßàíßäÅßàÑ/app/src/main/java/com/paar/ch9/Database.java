package com.paar.ch9;

/**
 * Created by gkdtn on 2016-11-02.
 */

public class Database{
    private int _ID;  // 자동으로 오름차순으로 증가
    private String location; //텍스트에 표시하게 될 정보
    private double lat; //위도
    private double lon; //경도
    private double alt; //고도

    public Database(int _ID, String location, double lat, double lon, double alt) {
        this._ID = _ID;
        this.location = location;
        this.lat = lat;
        this.lon = lon;
        this.alt = alt;
    }

    public int get_ID() {
        return _ID;
    }

    public void set_ID(int _ID) {
        this._ID = _ID;
    }

    public String getLocation() {
        return this.location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getLat() {
        return this.lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLon() {
        return this.lon;
    }

    public void setLon(double lon) {
        this.lon = lon;
    }

    public double getAlt(){ return this.alt; }

    public void setAlt(double alt) { this.alt = alt; }

}
