package com.paar.ch9;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.atomic.AtomicBoolean;

public class AugmentedView extends View {   //마커를 레이더와 카메라에 그리는 클래스

    private static final AtomicBoolean drawing = new AtomicBoolean(false);//실행중인지 확인하는 테그

    private static final Radar radar = new Radar(); //레이더선언
    //private static final float[] locationArray = new float[3];//마커위치를 저장
    private static final List<Marker> cache = new ArrayList<Marker>(); //화면을 그리는 동안 임시로 사용되는 캐시
    //private static final TreeSet<Marker> updated = new TreeSet<Marker>(); //위키와 트위터가 업데이트 될 때 사용

    public AugmentedView(Context context) {
        super(context);
    } //Super()를 통해 View에 묶이게 된다 - view에 올려지게 된다

	@Override
    protected void onDraw(Canvas canvas) {
    	if (canvas==null) return;

        if (drawing.compareAndSet(false, true)) {
	        List<Marker> collection = ARData.getMarkers();  //콜렉션으로 마커를 불러오고

            cache.clear();  //캐시를 초기화 시키고
            for (Marker m : collection) {   //콜렉션까지
                m.update(canvas, 0, 0);//마커를 업데이트하고 캔버스에 그리고
                if (m.isOnRadar()) cache.add(m);    //마커를 캐시에 추가한다
	        }
            collection = cache; //캐시 값을 콜렉션에 추가한다 - 콜렉션 값을 계속 업데이트한다.
	        ListIterator<Marker> iter = collection.listIterator(collection.size()); //콜렉션에 저장된 크기만큼 iter로 선언하여
	        while (iter.hasPrevious()) {    //그 크기만큼 캔버스에 드로우한다
	            Marker marker = iter.previous();
	            marker.draw(canvas);
	        }
	        if (AugmentedActivity.showRadar) radar.draw(canvas); //레이더에 보여지면 레이더에 그 캔버스를 그린다
	        drawing.set(false); //실행 중이 아님을 알린다 - 끝낸다.
        }
    }
}