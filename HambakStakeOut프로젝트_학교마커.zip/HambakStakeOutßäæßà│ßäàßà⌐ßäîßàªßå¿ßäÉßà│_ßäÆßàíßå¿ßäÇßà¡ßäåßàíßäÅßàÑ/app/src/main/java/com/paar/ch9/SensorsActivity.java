package com.paar.ch9;

import android.app.Activity;
import android.content.Context;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.paar.ch9.LowPassFilter.filter;

public class SensorsActivity extends Activity implements SensorEventListener, LocationListener {
    private static final String TAG = "SensorsActivity";//사용자의 클래스 이름 저장
    private static final AtomicBoolean computing = new AtomicBoolean(false); //작업이 현재 진행 중인지 판별

    //private static final int MIN_TIME = 10*1000;//시간 업데이트 범위
    //private static final int MIN_DISTANCE = 10;//위치 업데이트 범위
    private static final int MIN_TIME = 1*1000;//시간 업데이트 범위
    private static final int MIN_DISTANCE = 1;//위치 업데이트 범위

    private static final float temp[] = new float[9];//회전하는 동안 사용되는 임시 배열
    private static final float rotation[] = new float[9];//최종적으로 회전된 행렬 저장
    private static final float grav[] = new float[3];//중력 값 저장
    private static final float gyro[] = new float[3];//자이로 값 저장
    private static final float mag[] = new float[3];//자기장 값 저장

    private static final float test[] = new float[3]; //가속도와 자이로 더하여 저장하는 배열

    private static final Matrix worldCoord = new Matrix(); //기기의 위치 저장
    private static final Matrix magneticCompensatedCoord = new Matrix();//진북 좌표
    private static final Matrix xAxisRotation = new Matrix();//X축으로 90도 회전되었을 때 행렬 저장
    private static final Matrix magneticNorthCompensation = new Matrix();//자북 좌표

    private static GeomagneticField gmf = null;//GeomagneticField 인스턴스 저장

    private static float smooth[] = new float[3];//gra mag의 값에 로우패스 필터 적용

    private static SensorManager sensorMgr = null;
    private static List<Sensor> sensors = null;
    private static Sensor sensorGrav = null; //중력 가속도 센서
    private static Sensor sensorGyro = null;//자이로 센서
    private static Sensor sensorMag = null; //자기 센서
    private static LocationManager locationMgr = null;

    private float speed=0; // 흔들리는 정도의 스피드를 받아주는 실수형 값
    private long lastTime=0; //현재와 비교하기 위한 직전의 시간 값(흔들리기 직전의 값을 받기위해 현재의 값을 치환 시킴)
    private float lastX=0; //직전의 시간 값의 백터x값
    private float lastY=0;//직전의 시간 값의 백터y값
    private float lastZ=0;//직전의 시간 값의 백터z값
    private float x, y, z;  //현재 시간 값의 백터 x,y,z 값
    private static final int SHAKE_THRESHOLD = 800;   // speed가 이 상수 값보다 크면 메세지가 보내짐
    private static final int DATA_X = SensorManager.DATA_X; //센서의 x값을 받아주는 값
    private static final int DATA_Y = SensorManager.DATA_Y; //센서의 y값을 받아주는 값
    private static final int DATA_Z = SensorManager.DATA_Z; //센서의 z값을 받아주는 값

    private int count=0; // 메세지 카운드 시작
    private List<Marker> MarkerListForDistance;

	@Override  //크리에이트는 기본만 생성 - 이 클래스를 확장할 때 클래스를 실행 시키기 위해서 필요
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

	@Override
    public void onStart() {
        super.onStart();

        double angleX = Math.toRadians(-90);
        double angleY = Math.toRadians(-90);

        xAxisRotation.set( 1f,
                0f,
                0f,
                0f,
                (float) Math.cos(angleX),
                (float) -Math.sin(angleX),
                0f,
                (float) Math.sin(angleX),
                (float) Math.cos(angleX));

        try {
            sensorMgr = (SensorManager) getSystemService(SENSOR_SERVICE); //시스템 설정
            sensors = sensorMgr.getSensorList(Sensor.TYPE_ACCELEROMETER); // sensors[0]가속도 할당
            if (sensors.size() > 0) {sensorGrav = sensors.get(0);}//중력가속도 할당
            sensors = sensorMgr.getSensorList(Sensor.TYPE_MAGNETIC_FIELD); // sensors[1]자기장 할당
            if (sensors.size() > 0) {sensorMag = sensors.get(0);} // 자기장 할당
           sensors = sensorMgr.getSensorList(Sensor.TYPE_GYROSCOPE);
            if (sensors.size() > 0) {sensorGyro = sensors.get(0);} // 자이로스코프 설정

            /*sensorMgr.registerListener(this, sensorGrav, SensorManager.SENSOR_DELAY_FASTEST); // 중력가속도 리스너 설정
            sensorMgr.registerListener(this, sensorGyro, SensorManager.SENSOR_DELAY_FASTEST); // 자이로스코프 설정
            sensorMgr.registerListener(this, sensorMag, SensorManager.SENSOR_DELAY_FASTEST); // 자기장 리스너 설정*/
            sensorMgr.registerListener(this, sensorGrav, SensorManager.SENSOR_DELAY_GAME); // 중력가속도 리스너 설정
            sensorMgr.registerListener(this, sensorGyro, SensorManager.SENSOR_DELAY_GAME); // 자이로스코프 설정
            sensorMgr.registerListener(this, sensorMag, SensorManager.SENSOR_DELAY_GAME); // 자기장 리스너 설정


            locationMgr = (LocationManager) getSystemService(Context.LOCATION_SERVICE); //로케이션 서비스 선언
            locationMgr.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME, MIN_DISTANCE, this); //로케이션 없데이트

            try {

                try {
                    Location gps=locationMgr.getLastKnownLocation(LocationManager.GPS_PROVIDER); //gps 받으면 알려준다
                    Location network=locationMgr.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); //네트워크 받으면 알려준다
                    if(gps!=null)
                    {
                        onLocationChanged(gps); //gps받으면 받았다고 알려준다
                    }
                    else if (network!=null)
                    {
                        onLocationChanged(network); //네트워크 받았다고 알려준다
                    }
                    else
                    {
                        onLocationChanged(ARData.hardFix); //둘다 못받으면 ARData의 hardFix를 불러온다. 위도 경도 높이를 임의로 set한다
                    }
                } catch (Exception ex2) {
                    onLocationChanged(ARData.hardFix); //오류가 나도 임의로 set한다
                }

                gmf = new GeomagneticField((float) ARData.getCurrentLocation().getLatitude(),
                                           (float) ARData.getCurrentLocation().getLongitude(),
                                           (float) ARData.getCurrentLocation().getAltitude(),
                                           System.currentTimeMillis()); //GeomagneticField 인스턴스를 설정한다. 엥글y에 넣기 위해서
                angleY = Math.toRadians(-gmf.getDeclination()); //진북과 자북의 차이를 의미한다.

                synchronized (magneticNorthCompensation) { //magneticNorthCompensation을 처음 설정할 때 쓰인다
                    magneticNorthCompensation.toIdentity(); //magneticNorthCompensation 정의한다. 엥글 y가 쓰인다 - 정확한 나침판 위치를 구하는 것이다
                    magneticNorthCompensation.set( (float) Math.cos(angleY),
                                                  0f,
                                                  (float) Math.sin(angleY),
                                                  0f,
                                                  1f,
                                                  0f,
                                                  (float) -Math.sin(angleY),
                                                  0f,
                                                  (float) Math.cos(angleY));//magneticNorthCompensation 선언한다
                    magneticNorthCompensation.prod(xAxisRotation); //xAxisRotation와 곱해진다
                }
            } catch (Exception ex) {    //로케이션 센서를 받지 못하면 발생하는 예외
            	ex.printStackTrace();  //어디 오류가 나는지 알려주기위한 오류 검출 선언
            }
        } catch (Exception ex1) {   //센서메니저를 선언 받지 못하면 발생하는 예외
            try {       //센서메니저 널이 아니면 반환시키고 널로 리턴
                if (sensorMgr != null) {
                    sensorMgr.unregisterListener(this, sensorGrav);
                    sensorMgr.unregisterListener(this,sensorGyro);
                    sensorMgr.unregisterListener(this, sensorMag);
                    sensorMgr = null;
                }
                if (locationMgr != null) {  //로케이션메니저 널이 아니면 반환 시키고 널 리턴
                    locationMgr.removeUpdates(this);
                    locationMgr = null;
                }
            } catch (Exception ex2) {
            	ex2.printStackTrace();  //
            }
        }
    }

	@Override
    protected void onStop() {
        super.onStop();

        try {
            try {
                sensorMgr.unregisterListener(this, sensorGrav);
                sensorMgr.unregisterListener(this, sensorGyro);
                sensorMgr.unregisterListener(this, sensorMag);
            } catch (Exception ex) {
            	ex.printStackTrace();
            }
            sensorMgr = null;

            try {
                locationMgr.removeUpdates(this);
            } catch (Exception ex) {
            	ex.printStackTrace();
            }
            locationMgr = null;
        } catch (Exception ex) {
        	ex.printStackTrace();
        }
    }

    public void setCount(int count){ this.count = count; }
    public int getCount(){ return count; }
    public void clearCount(){count=0;}

    public void onSensorChanged(SensorEvent evt) {
        if (!computing.compareAndSet(false, true)) return;
       if (evt.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {    //가속도계로부터 값을 받아온다
           smooth = filter(0.5f, 1.0f, evt.values, grav);    //설정 전에 로우패스 통과 시킨다
           grav[0] = smooth[0];
           grav[1] = smooth[1];
           grav[2] = smooth[2];


/*           final float alpha = (float) 0.8;

           // Isolate the force of gravity with the low-pass filter.
           grav[0] = alpha * grav[0] + (1 - alpha) * evt.values[0];
           grav[1] = alpha * grav[1] + (1 - alpha) * evt.values[1];
           grav[2] = alpha * grav[2] + (1 - alpha) * evt.values[2];


           // Remove the gravity contribution with the high-pass filter.
           grav[0] = evt.values[0] - grav[0];
           grav[1] = evt.values[1] - grav[1];
           grav[2] = evt.values[2] - grav[2];*/



           long currentTime = System.currentTimeMillis(); // 현재 시간의 넣어둠
           long gabOfTime = (currentTime - lastTime);
           if (gabOfTime > 100) {
               lastTime = currentTime; // 변화가 100보다 크면 현재의 백터 값에 값을 넣어둠
               x = evt.values[DATA_X];
               y = evt.values[DATA_Y];
               z = evt.values[DATA_Z];
               speed = Math.abs(x + y + z - lastX - lastY - lastZ) / gabOfTime * 2000; // 계산을 통해 스피드를 계산
               // - 뒤에 상수 값이 높을 수록 민감도가 올라감
               if (speed > SHAKE_THRESHOLD) {
                   count++;
                   Log.d("test", "BeforeClear : "+count);
                   if(getCount()>6) {                          // 세번 흔들경우 메세지가 보내진다.
                       String cctvname = returnMarkername(); //가장 가까운 마커의 이름을 가져온
                       SmsManager smsManager = SmsManager.getDefault();
                       smsManager.sendTextMessage("번호입력", null,
                               "사용자 이름 : " +
                                       ", 사용자 집 주소 : " +
                                       ", 사용자 현재 위도 : " + (float) ARData.getCurrentLocation().getLatitude() +
                                       ", 사용자 현재 경도 : " + (float) ARData.getCurrentLocation().getLongitude() +
                                       ", 가장 가까운 곳 : " + cctvname
                               , null, null);
                       Log.d("test",
                               "메세지 보냄\n " +
                                       "사용자 이름 : "+
                                       "사용자 집 주소 : "+
                                       "사용자 현재 위도 : "+(float)ARData.getCurrentLocation().getLatitude()+
                                       "\n, 사용자 현재 경도 : "+ARData.getCurrentLocation().getLongitude()+
                                       "\n, 사용자 현재 고도 : "+ARData.getCurrentLocation().getAltitude()+
                                       "\n, 가장 가까운 곳 : "+cctvname
                       );
                       Toast.makeText(this, "전송 완료", Toast.LENGTH_LONG).show();
                       clearCount();
                       Log.d("test", "AfterClear : "+count);
                   }
               }
               lastX = evt.values[DATA_X];
               lastY = evt.values[DATA_Y];
               lastZ = evt.values[DATA_Z];
           }
        }else if (evt.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {    //나침판으로부터 값을 받아온다
            smooth = LowPassFilter.filter(2.0f, 4.0f, evt.values, mag); //설정 전에 로우패스 통과 시킨다
            mag[0] = smooth[0];
            mag[1] = smooth[1];
            mag[2] = smooth[2];

/*
          final float alpha = (float) 0.8;

           // Isolate the force of gravity with the low-pass filter.
           mag[0] = alpha * mag[0] + (1 - alpha) * evt.values[0];
           mag[1] = alpha * mag[1] + (1 - alpha) * evt.values[1];
           mag[2] = alpha * mag[2] + (1 - alpha) * evt.values[2];

           // Remove the gravity contribution with the high-pass filter.
           mag[0] = evt.values[0] -mag[0];
           mag[1] = evt.values[1] - mag[1];
           mag[2] = evt.values[2] - mag[2];
*/



        }else if (evt.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
           smooth = HighPassFilter.filter(evt.values);
           gyro[0] = smooth[0];
           gyro[1] = smooth[1];
           gyro[2] = smooth[2];

       }
        test[0] = gyro[0] + grav[0];
        test[1] = gyro[1] + grav[1];
        test[2] = gyro[2] + grav[2];


        //SensorManager.getRotationMatrix(temp, null, grav, mag); //temp배열(임시)에 값을 저장하고
        SensorManager.getRotationMatrix(temp,null,test,mag);

           SensorManager.remapCoordinateSystem(temp,
                SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X,
                rotation);                          //바로 로케이션배열에 저장시킨다. 안드로이드가 가로모드에 있을 때 사용할 수 있게 한다
        worldCoord.set(rotation[0], rotation[1], rotation[2],
                rotation[3], rotation[4], rotation[5],
                rotation[6], rotation[7], rotation[8]);     //로케이션배열의 값을 worldCoord에서 좌표로 변환 시킨다.
        magneticCompensatedCoord.toIdentity();  //선언하고
        synchronized (magneticNorthCompensation) {
            magneticCompensatedCoord.prod(magneticNorthCompensation);   //magneticNorthCompensation와 곱한다
        }
        magneticCompensatedCoord.prod(worldCoord);  //worldCoord와 곱한다
        magneticCompensatedCoord.invert();  //역으로 반전되고
        ARData.setRotationMatrix(magneticCompensatedCoord); //그 회전된 좌표가 ARData로 설정된다
        computing.set(false);
    }
    public void onProviderDisabled(String provider) {
        //Not Used
    }

    public void onProviderEnabled(String provider) {
        //Not Used
    }

    public void onStatusChanged(String provider, int status, Bundle extras) {
        //Not Used
    }
    public void onLocationChanged(Location location) {
        ARData.setCurrentLocation(location);        //로케이션에선 우선 ARData를 업데이트한다
        gmf = new GeomagneticField((float) ARData.getCurrentLocation().getLatitude(),  //gmf를 새로운 데이터로 다시 계산한다
                (float) ARData.getCurrentLocation().getLongitude(),
                (float) ARData.getCurrentLocation().getAltitude(),
                System.currentTimeMillis());

        double angleY = Math.toRadians(-gmf.getDeclination());  //앵글 와이에 이용하고 나머지는 센서와 동일하다

        synchronized (magneticNorthCompensation) {
            magneticNorthCompensation.toIdentity();

            magneticNorthCompensation.set((float) Math.cos(angleY),
                                         0f,
                                         (float) Math.sin(angleY),
                                         0f,
                                         1f,
                                         0f,
                                         (float) -Math.sin(angleY),
                                         0f,
                                         (float) Math.cos(angleY));

            magneticNorthCompensation.prod(xAxisRotation);
        }
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {    //오류 발생했을 때 알려준다
		if (sensor==null) throw new NullPointerException();

        if(sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD && accuracy==SensorManager.SENSOR_STATUS_UNRELIABLE) {
            Log.e(TAG, "Compass data unreliable");
        }
    }

    public String returnMarkername(){   //사용자의 위치에 따른 가장 가까운 위치의 마커의 Location 정보이름 가져오기
        double firstDis=500.0;
        double markerDis=0.0;
        String getname="";

        MarkerListForDistance = ARData.getMarkers();
        for(Marker marker : MarkerListForDistance){
            markerDis = marker.getDistance();
            if (firstDis > markerDis) {
                firstDis = markerDis;
                getname = marker.getName();
            }
        }
        return getname;
    }
}