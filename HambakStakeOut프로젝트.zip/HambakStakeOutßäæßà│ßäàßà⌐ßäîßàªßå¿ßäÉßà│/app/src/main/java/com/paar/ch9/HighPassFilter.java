package com.paar.ch9;

import android.widget.Filter;

public class HighPassFilter extends Filter {

    private static float factor = 0.9f;
    private static float[] prevAcc = new float[] {0.0f, 0.0f, 0.0f};

    public HighPassFilter() { super(); this.reset();}

    @Override
    protected FilterResults performFiltering(CharSequence charSequence) {
        return null;
    }

    @Override
    protected void publishResults(CharSequence charSequence, FilterResults filterResults) {

    }

    public static void reset() {
        prevAcc = new float[] {0.0f, 0.0f, 0.0f};
    }

    public static float[] filter(float[] value) {
        float[] retVal = new float[3];

        prevAcc[0] = (float) (value[0] * factor + prevAcc[0] * (1.0 - factor));
        prevAcc[1] = (float) (value[1] * factor + prevAcc[1] * (1.0 - factor));
        prevAcc[2] = (float) (value[2] * factor + prevAcc[2] * (1.0 - factor));

        retVal[0] = value[0] - prevAcc[0];
        retVal[1] = value[1] - prevAcc[1];
        retVal[2] = value[2] - prevAcc[2];

        return retVal;
    }

}
