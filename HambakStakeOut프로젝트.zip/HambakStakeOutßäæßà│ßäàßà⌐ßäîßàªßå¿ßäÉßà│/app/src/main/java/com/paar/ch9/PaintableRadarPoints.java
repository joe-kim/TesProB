package com.paar.ch9;

import android.graphics.Canvas;

public class PaintableRadarPoints extends PaintableObject { //레이더상에서 모든 마커의 상대적인 위치를 그리기 위해 사용되는 클래
    private final float[] locationArray = new float[3];
	private PaintablePoint paintablePoint = null;
	private PaintablePosition pointContainer = null;

	@Override
    public void paint(Canvas canvas) {
		if (canvas==null) throw new NullPointerException();

		//float range = ARData.getRadius() * 1000; //레이더 위에서 마커들의 상대적 위치를 표시해주기 위한 설정 값
		float range = ARData.getRadius() * 625; // 0.5 * 625

		float scale = range / Radar.RADIUS;
		for (Marker pm : ARData.getMarkers()) {
		    pm.getLocation().get(locationArray);
		    float x = locationArray[0] / scale;
		    float y = locationArray[2] / scale;

		    if ((x*x+y*y)<(Radar.RADIUS*Radar.RADIUS)) {
		        if (paintablePoint==null) paintablePoint = new PaintablePoint(pm.getColor(),true);
		        else paintablePoint.set(pm.getColor(),true);

		        if (pointContainer==null) pointContainer = new PaintablePosition( 	paintablePoint, 
		                (x+Radar.RADIUS-1), 
		                (y+Radar.RADIUS-1), 
		                0, 
		                1);
		        else pointContainer.set(paintablePoint, 
		                (x+Radar.RADIUS-1), 
		                (y+Radar.RADIUS-1), 
		                0, 
		                1);

		        pointContainer.paint(canvas);
		    }
		}
    }

	@Override
    public float getWidth() {
        return Radar.RADIUS * 2;
    } 	//점의 가로 지름을 반환

	@Override
    public float getHeight() {
        return Radar.RADIUS * 2;
    }	//점의 세로 지름을 반환
}