package com.paar.ch9;

/**
 * Created by gkdtn on 2016-11-02.
 */

/*
public class Database {
    private int _ID;
    private String Location;
    private double LAT;
    private double LON;
    private int High;

    public Database(int _ID,String Location,double LAT,double LON,int High){
        this._ID=_ID;
        this.Location=Location;
        this.LAT=LAT;
        this.LON=LON;
        this.High= High;


    }

    public int get_ID() {
        return _ID;
    }

    public void set_ID(int _ID) {
        this._ID = _ID;
    }

    public int getHigh() {
        return High;
    }

    public void setHigh(int High) {
        this.High = High;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public double getLON() {
        return LON;
    }

    public void setLON(double LON) {
        this.LON = LON;
    }

    public double getLAT() {
        return LAT;
    }

    public void setLAT(double LAT) {
        this.LAT = LAT;
    }
}
*/
public class SchoolDB{
    private int _ID;
    private String location;
    private double lat;
    private double lon;

    public SchoolDB(int _ID, String location, double lat, double lon) {
        this._ID = _ID;
        this.location = location;
        this.lat = lat;
        this.lon = lon;
    }

    public int get_ID() {
        return _ID;
    }

    public void set_ID(int _ID) {
        this._ID = _ID;
    }

    public String getLocation() {
        return this.location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getLat() {
        return this.lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLon() {
        return this.lon;
    }

    public void setLon(double lon) {
        this.lon = lon;
    }

}
