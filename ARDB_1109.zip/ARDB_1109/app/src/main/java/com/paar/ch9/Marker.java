package com.paar.ch9;

import android.graphics.Canvas;
import android.graphics.Color;
import android.location.Location;
import android.util.Log;

import java.text.DecimalFormat;

public class Marker implements Comparable<Marker> {//화면에 마커가 보여야 하는지를 계산하고 그에 따라 적절하게 이미지와 글자를 화면에 그린다

    private static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("@#");//레이더에 보이는 거리의 형식을 지정하는데 사용
        
    private static final Vector symbolVector = new Vector(0, 0, 0);//글자에 해당하는 기호를 회전 매트릭스를 이용해서 찾을 때 사용
    private static final Vector textVector = new Vector(0, 1, 0);//글자에 해당하는 위치를 회전 매트릭스를 이용해서 찾을 때 사용

    private final Vector screenPositionVector = new Vector(); //마커 기호와 그에 따른 글자를 그리고 위치를 잡는데 사용
    private final Vector tmpSymbolVector = new Vector();
    private final Vector tmpVector = new Vector();
    private final Vector tmpTextVector = new Vector();
    private final float[] distanceArray = new float[1];
    private final float[] locationArray = new float[3];
    private final float[] screenPositionArray = new float[3];

    private float initialY = 0.0f; //각각의 마커에 대한 초기 Y축 위치를 나타낸다
    
    private volatile static CameraModel cam = null;
    private volatile PaintableBoxedText textBox = null;
    private volatile PaintablePosition textContainer = null;

    protected final float[] symbolArray = new float[3]; //기호 그릴 때
    protected final float[] textArray = new float[3];//글자 그릴 때
    
    protected volatile PaintableObject gpsSymbol = null; //GPS 기호를 나타냄
    protected volatile PaintablePosition symbolContainer = null;//GPS 기호를 저장하는 저장소
    protected String name = null;//마커에 대한 고유 식별자 - 위키의 글제목 & 트위터의 사용자 이름
    protected volatile PhysicalLocationUtility physicalLocation = new PhysicalLocationUtility();//마커의 실제 세계에서의 물리적인 위치
    protected volatile double distance = 0.0;//사용자의 위치에서부터 physicalLocation까지의 거리를 미터단위로 저장
    protected volatile boolean isOnRadar = false;//마커의 가시성을 추적하는 플래그
    protected volatile boolean isInView = false;//마커의 가시성을 추적하는 플래그

    protected final Vector symbolXyzRelativeToCameraView = new Vector();    //카메라 화면에서 마커 기호와 글자의 위치를 결정
    protected final Vector textXyzRelativeToCameraView = new Vector();
    protected final Vector locationXyzRelativeToPhysicalLocation = new Vector();
    protected int color = Color.WHITE;

    private static boolean debugTouchZone = false; //TouchZone 디버깅 활성화 유무 - true와 값이 다름
    //private static boolean debugTouchZone = true; //TouchZone 디버깅 활성화 유무 - true와 값이 다름
    private static PaintableBox touchBox = null;    //디버깅 도우미
    private static PaintablePosition touchPosition = null;//디버깅 도우미

    private static boolean debugCollisionZone = false;//CollisionZone 디버깅 활성화 유무 - true와 값이 다름
    //private static boolean debugCollisionZone = true; //CollisionZone 디버깅 활성화 유무 - true와 값이 다름
    private static PaintableBox collisionBox = null;//디버깅 도우미
    private static PaintablePosition collisionPosition = null;//디버깅 도우미

	public Marker(String name, double latitude, double longitude, double altitude, int color) {
		set(name, latitude, longitude, altitude, color);
        //PhsicallLocation(=new PhysicalLocationUtility();)에 사용할 위도 경도 고도와 색상을 인자로 받아 넘겨준다
	}

	public synchronized void set(String name, double latitude, double longitude, double altitude, int color) {
		if (name==null) throw new NullPointerException();

		this.name = name;
		this.physicalLocation.set(latitude,longitude,altitude);
		this.color = color;
		this.isOnRadar = false;
		this.isInView = false;
		this.symbolXyzRelativeToCameraView.set(0, 0, 0);
		this.textXyzRelativeToCameraView.set(0, 0, 0);
		this.locationXyzRelativeToPhysicalLocation.set(0, 0, 0);
		this.initialY = 0.0f;
	}

	public synchronized String getName(){
		return this.name;
	}

    public synchronized int getColor() {
    	return this.color;
    }

    public synchronized double getDistance() {
        return this.distance;
    }

    public synchronized float getInitialY() {
        return this.initialY;
    }

    public synchronized boolean isOnRadar() {
        return this.isOnRadar;
    }

    public synchronized boolean isInView() {
        return this.isInView;
    }

    public synchronized Vector getScreenPosition() {//카메라 뷰에 관련된 기호와 글자의 위치를 이용해서 화면상의 마커의 위치를 계산한다
        symbolXyzRelativeToCameraView.get(symbolArray); //이미지 받아오고
        textXyzRelativeToCameraView.get(textArray); //텍스트 받아와서
        float x = (symbolArray[0] + textArray[0])/2;
        float y = (symbolArray[1] + textArray[1])/2;
        float z = (symbolArray[2] + textArray[2])/2;

        if (textBox!=null) y += (textBox.getHeight()/2);

        screenPositionVector.set(x, y, z);
        return screenPositionVector;
    }

    public synchronized Vector getLocation() {
        return this.locationXyzRelativeToPhysicalLocation;
    }

    public synchronized float getHeight() { //문자와 기호 이미지의 높이를 더해서 반환
        if (symbolContainer==null || textContainer==null) return 0f;
        return symbolContainer.getHeight()+textContainer.getHeight();
    }
    
    public synchronized float getWidth() {  //문자와 기호 이미지의 길이를 체크해서 둘중에 더 큰 값을 반환
        if (symbolContainer==null || textContainer==null) return 0f;
        float w1 = textContainer.getWidth();
        float w2 = symbolContainer.getWidth();
        return (w1>w2)?w1:w2;
    }
    
    public synchronized void update(Canvas canvas, float addX, float addY) {//화면을 업데이트하고 매트릭스를 생성하는 메소드
    	if (canvas==null) throw new NullPointerException();
    	
    	if (cam==null) cam = new CameraModel(canvas.getWidth(), canvas.getHeight(), true);//카메라 초기화 진행
    	cam.set(canvas.getWidth(), canvas.getHeight(), false);//캔버스에 사용할 캠 속성 업데이트하고
        cam.setViewAngle(CameraModel.DEFAULT_VIEW_ANGLE);//시야각 설정
        populateMatrices(cam, addX, addY);//캠과 업데이트된 x y 을 이용해 이미지&텍스트의 위치정보를 세팅함
        updateRadar();//
        updateView();//
    }

	private synchronized void populateMatrices(CameraModel cam, float addX, float addY) {
        //ARData로 얻은 회전 매트릭스를 이용해서 마커의 기호와 문자의 위치를 찾는다
		if (cam==null) throw new NullPointerException();
		
		tmpSymbolVector.set(symbolVector);
		tmpSymbolVector.add(locationXyzRelativeToPhysicalLocation);//위치정보값을 PhsicallLocationUtility로 보내 위치 파악(3차원으로)
        tmpSymbolVector.prod(ARData.getRotationMatrix());//그 값을 회전 매트릭스와 곱함
		
		tmpTextVector.set(textVector);
		tmpTextVector.add(locationXyzRelativeToPhysicalLocation);//위치정보값을 PhsicallLocationUtility로 보내 위치 파악(3차원으로)
		tmpTextVector.prod(ARData.getRotationMatrix());//그 값을 회전 매트릭스에 곱함

		cam.projectPoint(tmpSymbolVector, tmpVector, addX, addY);//곱해진 이미지 위치의 정보를 임시백터로 보냄
		symbolXyzRelativeToCameraView.set(tmpVector); //임시 백터의 값을 세팅시킴
		cam.projectPoint(tmpTextVector, tmpVector, addX, addY);//곱해진 텍스트 위치의 정보를 임시백터로 보냄
		textXyzRelativeToCameraView.set(tmpVector); //임시 백터의 값을 세팅시킴
	}

	private synchronized void updateRadar() {//레이더 상에서 마커의 위치를 업데이트할 때 사용
		isOnRadar = false;

		float range = ARData.getRadius() * 1000;
		float scale = range / Radar.RADIUS;
		locationXyzRelativeToPhysicalLocation.get(locationArray);
        float x = locationArray[0] / scale;
        float y = locationArray[2] / scale; // z==y Switched on purpose 
        symbolXyzRelativeToCameraView.get(symbolArray);
		if ((symbolArray[2] < -1f) && ((x*x+y*y)<(Radar.RADIUS*Radar.RADIUS))) {//(=마커의 위치가 레이더 상에 표시되어야 한다면)
			isOnRadar = true;//레이더를 true시킨다
		}
	}

    private synchronized void updateView() {//마커가 현재 보이는지 검사하는 것을 제외하면 updateRader()와 같은 역할을 한다
        isInView = false;

        symbolXyzRelativeToCameraView.get(symbolArray);
        float x1 = symbolArray[0] + (getWidth()/2);
        float y1 = symbolArray[1] + (getHeight()/2);
        float x2 = symbolArray[0] - (getWidth()/2);
        float y2 = symbolArray[1] - (getHeight()/2);
        if (x1>=-1 && x2<=(cam.getWidth()) 
            &&
            y1>=-1 && y2<=(cam.getHeight())
        ) {
            isInView = true;
        }
    }

    public synchronized void calcRelativePosition(Location location){//인자로 받은 location을 이용하여 새로운 상대적인 위치를 계산
		if (location==null) throw new NullPointerException();
		
	    updateDistance(location);
	    
		if (physicalLocation.getAltitude()==0.0){//얻은 3차원적인 고도값이 0일 경우 - 위도 세팅이 안되어 있을 경우 - 유효하지 않을 경우
            physicalLocation.setAltitude(location.getAltitude());
        }
		 //얻은 고도 값을 이용해서 백터를 생성하고, 그 백터를 이용해서 initialY를 업데이트해서 레이더에 뿌려준다
		PhysicalLocationUtility.convLocationToVector(location, physicalLocation, locationXyzRelativeToPhysicalLocation);
		this.initialY = locationXyzRelativeToPhysicalLocation.getY();
		updateRadar();
    }
    
    private synchronized void updateDistance(Location location) {//마커의 물리적인 위치와 사용자의 위치 차이를 새롭게 계산한다
        if (location==null) throw new NullPointerException();

        Location.distanceBetween(   //계산하는 메소드로 사용자의 위도 경도 값이랑 마커의 위도 경도값을 계산해서
                physicalLocation.getLatitude(),
                physicalLocation.getLongitude(),
                location.getLatitude(),
                location.getLongitude(),
                distanceArray);//여기에 넣는다
        distance = distanceArray[0];//그 값을 거리로 치환시킨다
    }

    public synchronized boolean handleClick(float x, float y) {//클릭한 디스플레이의 X,Y 값을 인자로 넘겨받는다.
    	if (!isOnRadar || !isInView) return false;//마커가 레이더 혹은 뷰 상에 없으면 false를 반환한다.
    	return isPointOnMarker(x,y,this); //isPointOnMarker에 값을 넘겨주고 호출한다
    }

    public synchronized boolean isMarkerOnMarker(Marker marker) { //두 번째 isMarkerOnMarker가 찾아낸 것은 다 반환시킨다
        return isMarkerOnMarker(marker,true);
    }

    //인자로 받은 마커가 현재 마커와 겹쳐지는 지를 검사하는 코드가 작성되어 있다 - 모서리 4개와 가운데 좌표, 총 5개를 비교하여 겹치면 마커위에 있다고 판단
    private synchronized boolean isMarkerOnMarker(Marker marker, boolean reflect) {
        marker.getScreenPosition().get(screenPositionArray); //받은 마커의 스크린상의 포지션을 screenPositionArray를 통해 받는다

        float x = screenPositionArray[0];   //첫번 째 비교 - 정중앙 좌표와 비교한다
        float y = screenPositionArray[1];        
        boolean middleOfMarker = isPointOnMarker(x,y,this); //얻어진 x y 값을 현재 가지고 있던 마커와 비교한다
        if (middleOfMarker) return true; //겹쳐져 있으면 true를 반환한다

        float halfWidth = marker.getWidth()/2;
        float halfHeight = marker.getHeight()/2;

        float x1 = x - halfWidth;
        float y1 = y - halfHeight;          /*마커의 왼쪽 위 좌표를 얻는 코드*/
        boolean upperLeftOfMarker = isPointOnMarker(x1,y1,this);
        if (upperLeftOfMarker) return true;

        float x2 = x + halfWidth;
        float y2 = y1;                      /*마커의 오른쪽 위 좌표를 얻는 코드*/
        boolean upperRightOfMarker = isPointOnMarker(x2,y2,this);
        if (upperRightOfMarker) return true;

        float x3 = x1;
        float y3 = y + halfHeight;          /*마커의 왼쪽 아래 좌표를 얻는 코드*/
        boolean lowerLeftOfMarker = isPointOnMarker(x3,y3,this);
        if (lowerLeftOfMarker) return true;

        float x4 = x2;
        float y4 = y3;                      /*마커의 오른쪽 아래 좌표를 얻는 코드*/
        boolean lowerRightOfMarker = isPointOnMarker(x4,y4,this);
        if (lowerRightOfMarker) return true;

        return (reflect)?marker.isMarkerOnMarker(this,false):false; //값이 false로 나오면 겹치지 않는 것으로 판단
    }

	private synchronized boolean isPointOnMarker(float x, float y, Marker marker) { //겹침을 계산하는 함수
	    marker.getScreenPosition().get(screenPositionArray);    //현재 가지고 있던 마커의 x,y를 가져온다
        float myX = screenPositionArray[0];//마커의 x를 myX에 넣는다
        float myY = screenPositionArray[1];//마커의 y를 myY에 넣는다
        float adjWidth = marker.getWidth()/2; //마커의 너비의 반을 구한다
        float adjHeight = marker.getHeight()/2;//마커의 높이의 반을 구한다

        float x1 = myX-adjWidth;//따로 받은 값에 넣는다
        float y1 = myY-adjHeight;
        float x2 = myX+adjWidth;
        float y2 = myY+adjHeight;

        if (x>=x1 && x<=x2 && y>=y1 && y<=y2) return true;  // 겹치는 부분이 있으면 true반환
        
        return false;   // 안겹치면 false
	}

    public synchronized void draw(Canvas canvas) {
        if (canvas==null) throw new NullPointerException();

        if (!isOnRadar || !isInView) return;
        
        if (debugTouchZone) drawTouchZone(canvas);
        if (debugCollisionZone) drawCollisionZone(canvas);
        drawIcon(canvas);
        drawText(canvas);
    }

    protected synchronized void drawCollisionZone(Canvas canvas) {//마커의 충돌 영역이 그려져야 할 경우에 두 마커 사이의 충돌 영역을 그린다
        if (canvas==null) throw new NullPointerException();
        
        getScreenPosition().get(screenPositionArray);
        float x = screenPositionArray[0];
        float y = screenPositionArray[1];        

        float width = getWidth();
        float height = getHeight();
        float halfWidth = width/2;
        float halfHeight = height/2;

        float x1 = x - halfWidth;
        float y1 = y - halfHeight;

        float x2 = x + halfWidth;
        float y2 = y1;

        float x3 = x1;
        float y3 = y + halfHeight;

        float x4 = x2;
        float y4 = y3;

        Log.w("collisionBox", "ul (x="+x1+" y="+y1+")");
        Log.w("collisionBox", "ur (x="+x2+" y="+y2+")");
        Log.w("collisionBox", "ll (x="+x3+" y="+y3+")");
        Log.w("collisionBox", "lr (x="+x4+" y="+y4+")");
        
        if (collisionBox==null) collisionBox = new PaintableBox(width,height,Color.WHITE,Color.RED);
        else collisionBox.set(width,height);

        float currentAngle = Utilities.getAngle(symbolArray[0], symbolArray[1], textArray[0], textArray[1])+90;
        
        if (collisionPosition==null) collisionPosition = new PaintablePosition(collisionBox, x1, y1, currentAngle, 1);
        else collisionPosition.set(collisionBox, x1, y1, currentAngle, 1);
        collisionPosition.paint(canvas);
    }

    protected synchronized void drawTouchZone(Canvas canvas) {//마커를 터치했을 때 해당 영역 위에 빨간색 사각형을 그린다
        if (canvas==null) throw new NullPointerException();
        
        if (gpsSymbol==null) return;
        
        symbolXyzRelativeToCameraView.get(symbolArray);
        textXyzRelativeToCameraView.get(textArray);        
        float x1 = symbolArray[0];
        float y1 = symbolArray[1];
        float x2 = textArray[0];
        float y2 = textArray[1];
        float width = getWidth();
        float height = getHeight();
        float adjX = (x1 + x2)/2;
        float adjY = (y1 + y2)/2;
        float currentAngle = Utilities.getAngle(symbolArray[0], symbolArray[1], textArray[0], textArray[1])+90;
        adjX -= (width/2);
        adjY -= (gpsSymbol.getHeight()/2);
        
        Log.w("touchBox", "ul (x="+(adjX)+" y="+(adjY)+")");
        Log.w("touchBox", "ur (x="+(adjX+width)+" y="+(adjY)+")");
        Log.w("touchBox", "ll (x="+(adjX)+" y="+(adjY+height)+")");
        Log.w("touchBox", "lr (x="+(adjX+width)+" y="+(adjY+height)+")");
        
        if (touchBox==null) touchBox = new PaintableBox(width,height,Color.WHITE,Color.GREEN);
        else touchBox.set(width,height);

        if (touchPosition==null) touchPosition = new PaintablePosition(touchBox, adjX, adjY, currentAngle, 1);
        else touchPosition.set(touchBox, adjX, adjY, currentAngle, 1);
        touchPosition.paint(canvas);
    }
    
    protected synchronized void drawIcon(Canvas canvas) {//아이콘을 그린다
    	if (canvas==null) throw new NullPointerException();

        if (gpsSymbol==null) gpsSymbol = new PaintableGps(36, 36, true, getColor());

        textXyzRelativeToCameraView.get(textArray);
        symbolXyzRelativeToCameraView.get(symbolArray);

        float currentAngle = Utilities.getAngle(symbolArray[0], symbolArray[1], textArray[0], textArray[1]);
        float angle = currentAngle + 90;

        if (symbolContainer==null) symbolContainer = new PaintablePosition(gpsSymbol, symbolArray[0], symbolArray[1], angle, 1);
        else symbolContainer.set(gpsSymbol, symbolArray[0], symbolArray[1], angle, 1);

        symbolContainer.paint(canvas);
    }

    protected synchronized void drawText(Canvas canvas) {//관련 문구를 화면에 표시한다
		if (canvas==null) throw new NullPointerException();
		
	    String textStr = null;

	    /*if (distance<1000.0) {
	        textStr = name + " ("+ DECIMAL_FORMAT.format(distance) + "m)";
	    } else {
	        double d=distance/1000.0;
	        textStr = name + " (" + DECIMAL_FORMAT.format(d) + "km)";
	    }*/
        if (distance<1000.0) {
            textStr = name + "("+ DECIMAL_FORMAT.format(distance) + "m)";
        } else {
            double d=distance/1000.0;
            textStr = name + "(" + DECIMAL_FORMAT.format(d) + "km)";
        }

	    textXyzRelativeToCameraView.get(textArray);
	    symbolXyzRelativeToCameraView.get(symbolArray);

	    float maxHeight = Math.round(canvas.getHeight() / 10f) + 1;
	    if (textBox==null) textBox = new PaintableBoxedText(textStr, Math.round(maxHeight / 2f) + 1, 300);
	    else textBox.set(textStr, Math.round(maxHeight / 2f) + 1, 300);

	    float currentAngle = Utilities.getAngle(symbolArray[0], symbolArray[1], textArray[0], textArray[1]);
        float angle = currentAngle + 90;

	    float x = textArray[0] - (textBox.getWidth() / 2);
	    float y = textArray[1] + maxHeight;

	    if (textContainer==null) textContainer = new PaintablePosition(textBox, x, y, angle, 1);
	    else textContainer.set(textBox, x, y, angle, 1);
	    textContainer.paint(canvas);
	}

    public synchronized int compareTo(Marker another) { //두 마커의 이름을 비교한다
        if (another==null) throw new NullPointerException();
        
        return name.compareTo(another.getName());
    }

    @Override
    public synchronized boolean equals(Object marker) { //두 마커의 이름이 같은지 비교한다
        if(marker==null || name==null) throw new NullPointerException();
        
        return name.equals(((Marker)marker).getName());
    }
}