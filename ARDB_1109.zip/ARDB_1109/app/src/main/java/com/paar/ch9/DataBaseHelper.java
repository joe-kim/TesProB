package com.paar.ch9;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/*
 * Created by gkdtn on 2016-10-28.
 .*/

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "school.db";
    public static final String DBLOCATION = "/data/data/com.paar.ch9/databases/";
    private Context mContext;
    private SQLiteDatabase mDatabase;

    public DataBaseHelper(Context context)
    {
        super(context,DBNAME,null,1);
        this.mContext=context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void openDatabase(){
        String dbpath=mContext.getDatabasePath(DBNAME).getPath();
        if(mDatabase!=null&& mDatabase.isOpen()){
            return;
        }
        mDatabase=SQLiteDatabase.openDatabase(dbpath,null,SQLiteDatabase.OPEN_READWRITE);
    }

    public void closeDatabase()
    {
        if(mDatabase!=null){
            mDatabase.close();
        }
    }

    public List<SchoolDB> getListDB()
    {
        SchoolDB schoolDB=null;
        List<SchoolDB> mschoolDBList=new ArrayList<SchoolDB>();
        openDatabase();
        Cursor cursor = mDatabase.rawQuery("SELECT * FROM school",null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            schoolDB=new SchoolDB(cursor.getInt(0),cursor.getString(1),cursor.getDouble(2),cursor.getDouble(3));
            Log.d("test",
                    "Int : "+cursor.getInt(0)+
                    "Location : "+cursor.getString(1)+
            "alt : "+cursor.getDouble(2)+
            "lon : "+cursor.getDouble(3));
            mschoolDBList.add(schoolDB);
            cursor.moveToNext();
        }
        cursor.close();
        closeDatabase();
        return mschoolDBList;
      }
}
