package com.paar.ch9;

import android.graphics.Canvas;
import android.graphics.Color;

public class PaintableBox extends PaintableObject { //상자의 윤곽을 그리는 클래스
    private float width=0, height=0;
	private int borderColor = Color.rgb(255, 255, 255);
	private int backgroundColor = Color.argb(128, 0, 0, 0);

	public PaintableBox(float width, float height) {	//두번 째 생성자를 호출하는 첫번 째 생성자
		this(width, height, Color.rgb(255, 255, 255), Color.argb(128, 0, 0, 0));
	}													//폭과 넓이만 받으면 기본 색으로 지정하여 생성자를 호출하여 상자를 생성한다

	public PaintableBox(float width, float height, int borderColor, int bgColor) {
		set(width, height, borderColor, bgColor);
	}

    public void set(float width, float height) {
        set(width, height, borderColor, backgroundColor);
    }

	public void set(float width, float height, int borderColor, int bgColor) {
	    this.width = width;
	    this.height = height;
	    this.borderColor = borderColor;
		this.backgroundColor = bgColor;
	}

	@Override
	public void paint(Canvas canvas) {
		if (canvas==null) throw new NullPointerException();

		setFill(true);
		setColor(backgroundColor);
		paintRect(canvas, 0, 0, width, height);

		setFill(false);
		setColor(borderColor);
		paintRect(canvas, 0, 0, width, height);
	}

	@Override
	public float getWidth() {
		return width;
	}

	@Override
	public float getHeight() {
		return height;
	}
}