package com.paar.ch9;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class WikipediaDataSource extends NetworkDataSource {

	//private static final String BASE_URL = "http://api.geonames.org/findNearbyPlaceNameJSON?";
	private static final String BASE_URL = "http://ws.geonames.org/findNearbyWikipediaJSON?"; //새로운 소스 베이스 url 할당

	private static Bitmap icon = null;
	
	public WikipediaDataSource(Resources res) {        
	    if (res==null) throw new NullPointerException();
        
        createIcon(res);
    }

    protected void createIcon(Resources res) {
        if (res==null) throw new NullPointerException();
        
        //icon=BitmapFactory.decodeResource(res, R.drawable.wikipedia); //트위터와 동일함 - 이미지만 다름
		icon=BitmapFactory.decodeResource(res, R.drawable.cctv); //CCTV 이미지로 바꿈
    }

	@Override
	public String createRequestURL(double lat, double lon, double alt, float radius, String locale) { //위키 URL로 바꾸는 방법
		return BASE_URL+
        "lat=" + lat +
        "&lng=" + lon +
		"&username=demo"+	 //크리에이트 유알엘은 리턴값만 우선 데이터베이스에 맞게 변경하여 준다
		"&radius="+ radius +	//반경의 값으로 설정된 값이다
        "&maxRows=40" +
        "&lang=" + locale;
	}

	@Override
	public List<Marker> parse(JSONObject root) { //오버라이드 받는 부분 이므로 네트워크데이터소스와 함께 변경
		if (root==null) return null;
		
		JSONObject jo = null; //JSON형태의 데이터를 관리해 주는 메서드
		JSONArray dataArray = null; //JSONObject가 들어가는 배열
    	List<Marker> markers=new ArrayList<Marker>();

		try {
			if(root.has("geonames")) dataArray = root.getJSONArray("geonames");
			if (dataArray == null) return markers;
				int top = Math.min(MAX, dataArray.length());
				for (int i = 0; i < top; i++) {					
					jo = dataArray.getJSONObject(i); //넘어온 Json을 jo로 넘겨주고
					Marker ma = processJSONObject(jo);//받은 Json으로 마커를 생성하여 빈 마커에 할당하고
					if(ma!=null) markers.add(ma);	//마커를 추가한다
				}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return markers;
	}
	
	private Marker processJSONObject(JSONObject jo) { //데이터베이스 받는 코드로 변경
		if (jo==null) return null;
		
        Marker ma = null;
        if (	jo.has("title") && 
        		jo.has("lat") && 
        		jo.has("lng") && 
        		jo.has("elevation")
        ) {
        	try {
        		ma = new IconMarker(			//jo(Json)의 내용을 ma(maker)에 할당해 준다
        				jo.getString("title"),
        				jo.getDouble("lat"),
        				jo.getDouble("lng"),
        				jo.getDouble("elevation"),
        				//Color.WHITE,
						Color.YELLOW,
        				icon);
        	} catch (JSONException e) {
        		e.printStackTrace();
        	}
        }
        return ma;
	}
}