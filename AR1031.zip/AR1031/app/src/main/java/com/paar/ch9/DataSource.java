package com.paar.ch9;

import java.util.List;

public abstract class DataSource { // 데이터 소스의 최상위 클래스 - 기본적인 getMarkers()만 추상으로 선언됨
    public abstract List<Marker> getMarkers();
}
