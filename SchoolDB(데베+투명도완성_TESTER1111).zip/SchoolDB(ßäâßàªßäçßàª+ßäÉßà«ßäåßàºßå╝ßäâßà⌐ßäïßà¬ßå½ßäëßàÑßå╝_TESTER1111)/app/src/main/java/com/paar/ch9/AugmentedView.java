package com.paar.ch9;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicBoolean;

public class AugmentedView extends View {   //마커를 레이더와 카메라에 그리는 클래스

    private static final AtomicBoolean drawing = new AtomicBoolean(false);//실행중인지 확인하는 테그

    private static final Radar radar = new Radar(); //레이더선언
    private static final float[] locationArray = new float[3];//마커위치를 저장
    private static final List<Marker> cache = new ArrayList<Marker>(); //화면을 그리는 동안 임시로 사용되는 캐시
    private static final TreeSet<Marker> updated = new TreeSet<Marker>(); //위키와 트위터가 업데이트 될 때 사용
    //private static final int COLLISION_ADJUSTMENT = 100; //겹치는 마커 위치 조정을 위해 상수 선언
    //private static final int COLLISION_ADJUSTMENT = 0; //겹치는 마커 위치 조정을 위해 상수 선언

    public AugmentedView(Context context) {
        super(context);
    } //Super()를 통해 View에 묶이게 된다 - view에 올려지게 된다

	@Override
    protected void onDraw(Canvas canvas) {
    	if (canvas==null) return;

        if (drawing.compareAndSet(false, true)) {
	        List<Marker> collection = ARData.getMarkers();  //콜렉션으로 마커를 불러오고

            cache.clear();  //캐시를 초기화 시키고
            for (Marker m : collection) {   //콜렉션까지
                m.update(canvas, 0, 0);//마커를 업데이트하고 캔버스에 그리고
                if (m.isOnRadar()) cache.add(m);    //마커를 캐시에 추가한다
	        }
            collection = cache; //캐시 값을 콜렉션에 추가한다 - 콜렉션 값을 계속 업데이트한다.
/*
	        if (AugmentedActivity.useCollisionDetection) {
                adjustForCollisions(canvas,collection);
            }   //마커 위치가 겹치는지 확인하고(useCollisionDetection), 겹치면 마커의 위치를 조정한다(adjustForCollisions)
*/

	        ListIterator<Marker> iter = collection.listIterator(collection.size()); //콜렉션에 저장된 크기만큼 iter로 선언하여
	        while (iter.hasPrevious()) {    //그 크기만큼 캔버스에 드로우한다
	            Marker marker = iter.previous();
	            marker.draw(canvas);
	        }
	        if (AugmentedActivity.showRadar) radar.draw(canvas); //레이더에 보여지면 레이더에 그 캔버스를 그린다
	        drawing.set(false); //실행 중이 아님을 알린다 - 끝낸다.
        }
    }

	/*private static void adjustForCollisions(Canvas canvas, List<Marker> collection) {   //겹치는 것 조정하는 메소드
	    updated.clear();    //위키 트위터 불러오는거 초기화 시키고 - 마커를 나타내주는게 updated
        for (Marker marker1 : collection) {
            if (updated.contains(marker1) || !marker1.isInView()) continue; //마커 콜렉션까지 검사하여
                                                        // 같은 마크인지 아닌지 확인하고 맞으면 메소드 종료

            int collisions = 1; //단 두개만 검사하겠단 것
            for (Marker marker2 : collection) { //
                if (marker1.equals(marker2) || updated.contains(marker2) || !marker2.isInView()) continue; //같은 알고리즘

                if (marker1.isMarkerOnMarker(marker2)) {    //마커 위에 있으면 마커2의 위치를 재조정하여 업데이트에 마커2를 다시 알린다
                    marker2.getLocation().get(locationArray);
                    float y = locationArray[1];
                    float h = collisions*COLLISION_ADJUSTMENT;
                    locationArray[1] = y+h;
                    marker2.getLocation().set(locationArray);
                    marker2.update(canvas, 0, 0);
                    collisions++;
                    updated.add(marker2);
                }
            }
            updated.add(marker1); //마커1도 다시 나타내 준다
        }
	}*/
}