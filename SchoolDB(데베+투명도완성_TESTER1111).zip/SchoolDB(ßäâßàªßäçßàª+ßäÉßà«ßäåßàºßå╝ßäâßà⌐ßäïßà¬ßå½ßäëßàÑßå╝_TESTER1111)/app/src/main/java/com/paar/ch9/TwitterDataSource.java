/*
package com.paar.ch9;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TwitterDataSource extends NetworkDataSource {
	private static final String URL = "http://search.twitter.com/search.json";

	private static Bitmap icon = null;

	public TwitterDataSource(Resources res) {
		if (res==null) throw new NullPointerException();
		
		createIcon(res);//Resources에서 이미지 파일을 얻어온다
	}
	
	protected void createIcon(Resources res) {
		if (res==null) throw new NullPointerException();
		
		icon=BitmapFactory.decodeResource(res, R.drawable.twitter);//Resources에서 이미지 파일을 얻어온다
	}

	@Override
	public String createRequestURL(double lat, double lon, double alt, float radius, String locale) {
		return URL+"?geocode=" + lat + "%2C" + lon + "%2C" + Math.max(radius, 1.0) + "km";	//twitter URL생성
	}

	@Override
	public List<Marker> parse(String url) {
		if (url==null) throw new NullPointerException();
		
		InputStream stream = null;
    	stream = getHttpGETInputStream(url);
    	if (stream==null) throw new NullPointerException();
    	
    	String string = null;
    	string = getHttpInputString(stream);	//url을 스트링으로 변경
    	if (string==null) throw new NullPointerException();
    	
    	JSONObject json = null;	//json선언
    	try {
    		json = new JSONObject(string);
    	} catch (JSONException e) {
    	    e.printStackTrace();
    	}
    	if (json==null) throw new NullPointerException();
    	
    	return parse(json);	//json을 판별하여 두 번째 parse()로 리턴 - Json을 리턴
	}

	@Override
	public List<Marker> parse(JSONObject root) {
		if (root==null) throw new NullPointerException();
		
		JSONObject jo = null;
		JSONArray dataArray = null;
    	List<Marker> markers=new ArrayList<Marker>();

		try {
			if(root.has("results")) dataArray = root.getJSONArray("results"); //넘어온 Json을 받고
			if (dataArray == null) return markers;
			int top = Math.min(MAX, dataArray.length()); //배열 크기와 마커의 최댓값과 비교하여 작은 값을 선정 - 배열 안벗어나기위해
			for (int i = 0; i < top; i++) {					
				jo = dataArray.getJSONObject(i); //넘어온 Json을 jo로 넘겨주고
				Marker ma = processJSONObject(jo);	//받은 Json으로 마커를 생성하여 빈 마커에 할당하고
				if(ma!=null) markers.add(ma);	//마커를 추가한다
			}
		} catch (JSONException e) {
		    e.printStackTrace();
		}
		return markers;	//마커 리턴
	}
	
	private Marker processJSONObject(JSONObject jo) { //Json을 이용하여 마커를 생성하여 리턴함	-- 마커를 반환
		if (jo==null) throw new NullPointerException();
		
		if (!jo.has("geo")) throw new NullPointerException();
		
		Marker ma = null;
		try {
			Double lat=null, lon=null; //위도 경도 선언
			
			if(!jo.isNull("geo")) {
				JSONObject geo = jo.getJSONObject("geo"); //geo 정보가 화면과 레이더를 그리는데 중요하게 사용
				JSONArray coordinates = geo.getJSONArray("coordinates"); //배열 coordinate에 위도 경도 선언
				lat=Double.parseDouble(coordinates.getString(0));	//위도 값 얻음
				lon=Double.parseDouble(coordinates.getString(1));	//경도 값 얻음
		} else if(jo.has("location")) {
				Pattern pattern = Pattern.compile("\\D*([0-9.]+),\\s?([0-9.]+)");
				Matcher matcher = pattern.matcher(jo.getString("location")); //트윗의 위치 얻어옴

				if(matcher.find()){
					lat=Double.parseDouble(matcher.group(1));
					lon=Double.parseDouble(matcher.group(2));				//트윗의 위치 얻어옴
				}					
			}
			if(lat!=null) {
				String user=jo.getString("from_user");	//사용자 얻어온다

				ma = new IconMarker(
						user+": "+jo.getString("text"), //내용 얻어온다 => 김지호: ~내용~ 으로 보인다
						lat, 
						lon, 
						0,
						Color.RED,
						icon);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ma;	//마커를 반환
	}
}*/
