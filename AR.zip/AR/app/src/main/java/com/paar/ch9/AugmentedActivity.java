package com.paar.ch9;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;

import java.text.DecimalFormat;

public class AugmentedActivity extends SensorsActivity implements OnTouchListener {
    //AugmentedView를 확장해서 화면에 띄울 카메라와 레이아웃 설정하고 줌바(seekBar)를 선언하고 값을 할당하는 클래스
    private static final String TAG = "AugmentedActivity";
    private static final DecimalFormat FORMAT = new DecimalFormat("#.##");  //레이더에 현재반경 표시할 때 나타내는 포멧형식 지정
    /*
    private static final int ZOOMBAR_BACKGROUND_COLOR = Color.argb(125,55,55,55);   //시크바 컬러 설정
    private static final String END_TEXT = FORMAT.format(AugmentedActivity.MAX_ZOOM)+" km"; //레이더에 표시하는 텍스트 형식 - "#.##"+Km
    private static final int END_TEXT_COLOR = Color.WHITE;  //색상은 화이트
*/
    protected static WakeLock wakeLock = null;  //카메라 꺼짐켜짐 확인
    protected static CameraSurface camScreen = null;    //카메라 할당

    //protected static VerticalSeekBar myZoomBar = null;  //SeekBar할당

   // protected static TextView endLabel = null;      //END_TEXT 레이아웃 선언

    protected static LinearLayout zoomLayout = null;    //SeekBar 레이아웃 선언
    protected static AugmentedView augmentedView = null;    //AugmentedView를 확장

/*    public static final float MAX_ZOOM = 100; //in KM   //최대 반경 값 선언 - 나중에 바꿀 것 (약 2키로?)
    public static final float ONE_PERCENT = MAX_ZOOM/100f;
    public static final float TEN_PERCENT = 10f*ONE_PERCENT;
    public static final float TWENTY_PERCENT = 2f*TEN_PERCENT;
    public static final float EIGHTY_PERCENTY = 4f*TWENTY_PERCENT;*/

    public static boolean useCollisionDetection = true; //충돌 메소드 사용할지 안할지 판별
    public static boolean showRadar = true; //레이더 표시할지 안할지 판별
    public static boolean showZoomBar = true;   //시크바 표시할지 안할지 판별

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        camScreen = new CameraSurface(this);
        setContentView(camScreen);  //카메라 surface선언

        augmentedView = new AugmentedView(this);    //뷰 확장하여 할당
        augmentedView.setOnTouchListener(this); //뷰 리스너 설정
        LayoutParams augLayout = new LayoutParams(  LayoutParams.WRAP_CONTENT, 
                                                    LayoutParams.WRAP_CONTENT);
        addContentView(augmentedView,augLayout);    //augmentedView를 Wrap-ConTent로 하여 Content에 추가

        /*불필요한 부분 주석 처리*/
        
/*        zoomLayout = new LinearLayout(this);
        zoomLayout.setVisibility((showZoomBar)?LinearLayout.VISIBLE:LinearLayout.GONE); //true false에 따라 달라짐
        zoomLayout.setOrientation(LinearLayout.VERTICAL);
        zoomLayout.setPadding(5, 5, 5, 5);
        zoomLayout.setBackgroundColor(ZOOMBAR_BACKGROUND_COLOR);    //시크바 레이아웃 선언

        endLabel = new TextView(this);
        endLabel.setText(END_TEXT);
        endLabel.setTextColor(END_TEXT_COLOR);
        LinearLayout.LayoutParams zoomTextParams =  new LinearLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        zoomLayout.addView(endLabel, zoomTextParams);   //END_TEXT 레이아웃 선언*/

        /*myZoomBar = new VerticalSeekBar(this);
        myZoomBar.setMax(100);
        myZoomBar.setProgress(50);
        myZoomBar.setOnSeekBarChangeListener(myZoomBarOnSeekBarChangeListener); //줌바 Change리스너 설정
        LinearLayout.LayoutParams zoomBarParams =  new LinearLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT,LayoutParams.FILL_PARENT);
        zoomBarParams.gravity = Gravity.CENTER_HORIZONTAL;
        zoomLayout.addView(myZoomBar, zoomBarParams);   //시크바 레이아웃을 zoomBarParams에 설정된 위치에 표시해줌*/

/*        FrameLayout.LayoutParams frameLayoutParams =
                new FrameLayout.LayoutParams(
                        LayoutParams.WRAP_CONTENT, LayoutParams.FILL_PARENT, Gravity.RIGHT);
        addContentView(zoomLayout,frameLayoutParams);   //시크바 레이아웃을 frameLayoutParams에 설정된 위치에 표시해줌
                                                        // ==> 위치 zoomBarParams(center) + frameLayoutParams(right)
        */
        //updateDataOnZoom(); //줌 변화에 따른 업데이트

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);   //화면을 켜고 사용하지 않는 상태에서는
                                        // 어둡게 보이게하는 WakeLock을 얻어오기 위해 파워 메니저 시스템 서비스를 선언
        wakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "DimScreen"); //할당해줌
    }

	@Override
	public void onResume() {
		super.onResume();

		wakeLock.acquire(); //실행중에 사용할 수 있게함
	}

	@Override
	public void onPause() {
		super.onPause();

		wakeLock.release(); //반환
	}
	
	@Override
    public void onSensorChanged(SensorEvent evt) {
        super.onSensorChanged(evt);

        if (    evt.sensor.getType() == Sensor.TYPE_ACCELEROMETER || 
                evt.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
        {
            augmentedView.postInvalidate(); //센서가 변화되면 augmentedView를 무효화시키고 다시 onDraw()한다
        }
    }
    
/*    private OnSeekBarChangeListener myZoomBarOnSeekBarChangeListener = new OnSeekBarChangeListener() {
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            updateDataOnZoom();     //시크바가 변화되면 레이더 줌 크기를 업데이트하고
            camScreen.invalidate(); //카메라를 무효화하고 다시 그린다
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
            //Not used
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            updateDataOnZoom(); //시크바가 더이상 바뀌지 않을 때도 레이더 줌 크기를 업데이트하고
            camScreen.invalidate();//카메라를 무효화하고 다시 그린다
        }
    };*/

 /*   private static float calcZoomLevel(){
        int myZoomLevel = myZoomBar.getProgress();  //시크바의 Progress를 받아 할당하고
        float out = 0;  // out은 퍼센트 값을 할당할 때 사용된다

        float percent = 0;
        if (myZoomLevel <= 25) {
            percent = myZoomLevel/25f;
            out = ONE_PERCENT*percent;
        } else if (myZoomLevel > 25 && myZoomLevel <= 50) {
            percent = (myZoomLevel-25f)/25f;
            out = ONE_PERCENT+(TEN_PERCENT*percent);
        } else if (myZoomLevel > 50 && myZoomLevel <= 75) {
            percent = (myZoomLevel-50f)/25f;
            out = TEN_PERCENT+(TWENTY_PERCENT*percent);
        } else {
            percent = (myZoomLevel-75f)/25f;
            out = TWENTY_PERCENT+(EIGHTY_PERCENTY*percent);
        }
        return out; //리턴한다
    }*/

        //레이더의 반경 조절하는 업데이트메소드
/*    protected void updateDataOnZoom() {
        float zoomLevel = calcZoomLevel();  //out(퍼센트)값을 받아 zoomLevel에 저장
        ARData.setRadius(zoomLevel);    //zoomLevel 이용하여 반지름 설정
        ARData.setZoomLevel(FORMAT.format(zoomLevel)); //zoomLevel에 따른 포멧재설정
        //ARData.setZoomProgress(myZoomBar.getProgress()); //시크바의 프로그래스를 재설정
    }*/

	public boolean onTouch(View view, MotionEvent me) { //마커를 터치했을 때 작동하는 터치 메소드
	    for (Marker marker : ARData.getMarkers()) {
	        if (marker.handleClick(me.getX(), me.getY())) {
	            if (me.getAction() == MotionEvent.ACTION_UP) markerTouched(marker);
	            return true;
	        }
	    }
		return super.onTouchEvent(me);
	};
	
	protected void markerTouched(Marker marker) {
		Log.w(TAG,"markerTouched() not implemented."); //아무일도 일어나지 않는다고 선언함 - 나중에 바꿔도 될 듯 - 간략하게 토스트라도
	}
}