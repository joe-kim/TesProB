package com.paar.ch9;

import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AugmentedActivity {
    private static final String TAG = "MainActivity";
    private static final String locale = "en";  //혹시 발생할 수 있는 랭귀지 문제를 영어로만 설정하여 해결
    //private static final String locale = Locale.getDefault().getLanguage(); //지역의 언어로 locale 설정
    private static final BlockingQueue<Runnable> queue = new ArrayBlockingQueue<Runnable>(1);//작업 단순화 위해 변수 설정
    private static final ThreadPoolExecutor exeService = new ThreadPoolExecutor(1, 1, 20, TimeUnit.SECONDS, queue);
                                                    //ThreadPoolExecutor와 함께 인자의 queue를 가리킨다.
	private static final Map<String,NetworkDataSource> sources = new ConcurrentHashMap<String,NetworkDataSource>();
                                                    //데이터 소스를 저장하는 source에 연결된 Map이 있다

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LocalDataSource localData = new LocalDataSource(this.getResources()); //로컬데이터소스를 선언한다
        ARData.addMarkers(localData.getMarkers());//로컬데이터소스에 나온 마커를 ARData에 마커추가한다

        /*NetworkDataSource twitter = new TwitterDataSource(this.getResources());//트위터를 얻어와
        sources.put("twitter",twitter); //Map에 연결한다*/

        NetworkDataSource wikipedia = new WikipediaDataSource(this.getResources());//위키를 얻어와
        sources.put("wiki",wikipedia); //Map에 연결한다  - sources 맵핑하는 과정 수정
    }

	@Override
    public void onStart() {
        super.onStart();
        
        Location last = ARData.getCurrentLocation();//가장 최근의 위치를 ARData에서 얻어와서 저장하고
        updateData(last.getLatitude(),last.getLongitude(),last.getAltitude());//최신위치의 경도위도고도 값을 업데이트한다
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) { //메뉴바 설정한다
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.v(TAG, "onOptionsItemSelected() item="+item);
        switch (item.getItemId()) {
            case R.id.showRadar:
                showRadar = !showRadar;//현재값이 트루라면 폴스가 나타남
                item.setTitle(((showRadar)? "Hide" : "Show")+" Radar");
                break;
            case R.id.showZoomBar:
                showZoomBar = !showZoomBar; //마찬가지
                item.setTitle(((showZoomBar)? "Hide" : "Show")+" Zoom Bar");
                zoomLayout.setVisibility((showZoomBar)?LinearLayout.VISIBLE:LinearLayout.GONE);
                break;
            case R.id.exit:
                finish();
                break;
        }
        return true;
    }

	@Override
    public void onLocationChanged(Location location) {
        super.onLocationChanged(location);
        
        updateData(location.getLatitude(),location.getLongitude(),location.getAltitude());  //지역이 변경되면 업데이트한다
    }

	@Override
	protected void markerTouched(Marker marker) {
        Toast t = Toast.makeText(getApplicationContext(), marker.getName(), Toast.LENGTH_SHORT);
        t.setGravity(Gravity.CENTER, 0, 0);//마커를 가운데에 뛰우고 마커이름을 짧게 토스트한다
        t.show();
	}

 /*   @Override
	protected void updateDataOnZoom() {
	    super.updateDataOnZoom();   //AugmenteActivity의 시크바에 따른 레이더 줌 크기 업데이트하고
        Location last = ARData.getCurrentLocation(); //로케이션에 ARData의 최신위치 업데이트하고
        updateData(last.getLatitude(),last.getLongitude(),last.getAltitude());//위도경도고도 데이터를 이용하여 소스 업데이트한다
	}*/
    
    private void updateData(final double lat, final double lon, final double alt) {
        try {
            exeService.execute(
                new Runnable() {    //Runnable()을 이용하여 위키나 트위터의 source를 다운로드한다
                    
                    public void run() {
                        for (NetworkDataSource source : sources.values())//소스 크기만큼
                            download(source, lat, lon, alt);
                    }
                }
            );
        } catch (RejectedExecutionException rej) {//자료를 받을 큐 공간이 부족하면 예외발생 시
            Log.w(TAG, "Not running new download Runnable, queue is full.");
        } catch (Exception e) { //그외의 예외 발생 시
            Log.e(TAG, "Exception running download Runnable.",e);
        }
    }
    
    private static boolean download(NetworkDataSource source, double lat, double lon, double alt) {
		if (source==null) {
            Log.d(TAG,"Can`t connect with any url");
            return false;//url이 널이면(url을 얻어오지 못했으면) 거짓을 반환한다
        }
		
		String url = null;
		try {
			url = source.createRequestURL(lat, lon, alt, ARData.getRadius(), locale);//데이터를 얻어온다 - 여기 부분 살펴볼 것
		} catch (NullPointerException e) {
			return false;
		}
    	
		List<Marker> markers = null;
		try {
			markers = source.parse(url);    //얻어온 데이터를 분석하여(어디거인지?)
		} catch (NullPointerException e) {
			return false;
		}

    	ARData.addMarkers(markers);//ARData에 마커 추가한다

    	return true;//성공하면 트루반환
    }
}